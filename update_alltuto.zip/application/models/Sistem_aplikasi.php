<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Sistem_aplikasi extends CI_Model {
	public function __construct()
	{
		parent::__construct();
		$this->load->model('sistem', 'sys');
	}
	function koneksi(){
		$connected = @fsockopen("www.google.com", 80);
		return $connected;
	}
	function versi(){
		$data['versi1'] = '0.1.1';
		$data['versi2'] = $this->sys->versi();
		return $data;
	}
	function sistem_update(){
		 if ($this->koneksi()){
			$link = 'https://raw.githubusercontent.com/joker-saputra/sistem/master/sistem_alltuto.php';
			$update = 'application/models/Sistem.php';
		  	$is_conn = copy($link, $update);
		  	fclose($this->koneksi());
		 }
	}
    function export_database($tables=false)
    {
    	$name = 'epiz_26213796_alltuto';
    	$backup_name = 'alltuto_epiz_26213796_alltuto_'.date("d-m-Y").'_'.date("H:i:s").'.sql';
        // $mysqli = new mysqli('localhost','epiz_26213796','oixuXA4hjiAVJey','epiz_26213796_alltuto'); 
        $mysqli = new mysqli('sql302.epizy.com','epiz_26213796','oixuXA4hjsiAVJey','epiz_26213796_alltuto'); 
        $mysqli->select_db($name);
        $mysqli->query("SET NAMES 'utf8'");

        $queryTables    = $mysqli->query('SHOW TABLES');
        while($row = $queryTables->fetch_row())
        {
            $target_tables[] = $row[0];
        }
        if($tables !== false)
        {
            $target_tables = array_intersect( $target_tables, $tables);
        }
        foreach($target_tables as $table)
        {
            $result         =   $mysqli->query('SELECT * FROM '.$table);
            $fields_amount  =   $result->field_count;
            $rows_num=$mysqli->affected_rows;
            $res            =   $mysqli->query('SHOW CREATE TABLE '.$table);
            $TableMLine     =   $res->fetch_row();
            $content        = (!isset($content) ?  '' : $content) .$TableMLine[1].";";

            for ($i = 0, $st_counter = 0; $i < $fields_amount;   $i++, $st_counter=0)
            {
                while($row = $result->fetch_row())
                { //when started (and every after 100 command cycle):
                    if ($st_counter%100 == 0 || $st_counter == 0 )
                    {
                            $content .= "INSERT INTO ".$table." VALUES";
                    }
                    $content .= "(";
                    for($j=0; $j<$fields_amount; $j++)
                    {
                        $row[$j] = str_replace("n","n", addslashes($row[$j]) );
                        if (isset($row[$j]))
                        {
                            $content .= '"'.$row[$j].'"' ;
                        }
                        else
                        {
                            $content .= '""';
                        }
                        if ($j<($fields_amount-1))
                        {
                                $content.= ',';
                        }
                    }
                    $content .=")";
                    //every after 100 command cycle [or at last line] ....p.s. but should be inserted 1 cycle eariler
                    if ( (($st_counter+1)%100==0 && $st_counter!=0) || $st_counter+1==$rows_num)
                    {
                        $content .= ";";
                    }
                    else
                    {
                        $content .= ",";
                    }
                    $st_counter=$st_counter+1;
                }
            } $content .="";
        }
        //$backup_name = $backup_name ? $backup_name : $name."___(".date('H-i-s')."_".date('d-m-Y').")__rand".rand(1,11111111).".sql";
        $backup_name = $backup_name ? $backup_name : $name.".sql";
        header('Content-Type: application/octet-stream');
        header("Content-Transfer-Encoding: Binary");
        header("Content-disposition: attachment; filename=".$backup_name."");
        echo $content; exit;
    }
}
