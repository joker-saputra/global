<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Sistem_aplikasi extends CI_Model {
	public function __construct()
	{
		parent::__construct();
		$this->load->model('sistem', 'sys');
	}
	function koneksi(){
		$connected = @fsockopen("www.google.com", 80);
		return $connected;
	}
	function versi(){
		$data['versi1'] = '0.1.0';
		$data['versi2'] = $this->sys->versi();
		return $data;
	}
	function sistem_update(){
		 if ($this->koneksi()){
			$link = 'https://raw.githubusercontent.com/joker-saputra/sistem/master/sistem_alltuto.php';
			$update = 'application/models/Sistem.php';
		  	$is_conn = copy($link, $update);
		  	fclose($this->koneksi());
		 }
	}
}
