
    <a href="<?= base_url(); ?>buildSystems/index3.html" class="brand-link">
      <img src="<?= base_url(); ?>buildSystems/dist/img/AdminLTELogo.png" alt="AdminLTE Logo" class="brand-image img-circle elevation-3"
           style="opacity: .8">
      <span class="brand-text font-weight-light">AdminLTE 3</span>
    </a>