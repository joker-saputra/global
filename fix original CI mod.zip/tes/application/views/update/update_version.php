<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<div class="row">
	<div class="col-md-12">
		<div class="card card-default">
		  <div class="card-header">
			<?php
			 if ($this->sistem->koneksi()){
			 	?>
				    <h3 class="card-title">
				    <i class="fas fa-circle" style="color: green;"></i>
				      Sistem Online
				    </h3>
			 	<?php
			  	fclose($this->sistem->koneksi());
			 }else{
			 	?>
				    <h3 class="card-title">
				    <i class="fas fa-circle" style="color: red;"></i>
				      Sistem Offline
				    </h3>
				<?php
			 }
			?>
		  </div>
		  <div class="card-body">
        	<?php
        	if ($this->sistem->versi()['versi1'] != $this->sistem->versi()['versi2']) {
        		?>
        		<div class="callout callout-info">
                  <h5>Sistem baru telah keluar versi <b><?= $this->sistem->versi()['versi2']; ?></b>. Silahkan melakukan pembaruan sistem.</h5>

                  <p>Pembaruan sistem tidak akan merubah data pada database.</p>
                </div>
        		<p class="text-center"><button class="btn btn-outline-info" onclick="window.location.href='<?= base_url('update?to=1'); ?>'"><i class="fas fa-sync"></i> Pembaruan Sistem</button></p>
        		<?php
        	}
        	?>
		  </div>
		</div>
	</div>
</div>
<?php
if (isset($_GET['to'])) {
	if (!is_file('uploads/update.zip')) {
		$link = 'https://raw.githubusercontent.com/joker-saputra/global/master/license.zip';
		$update = 'uploads/update.zip';
	  	$is_conn = copy($link, $update);
  		echo "
  			<script>
  				window.location.href='".base_url('update?sync=1')."';
  			</script>
  		";
	}
}
if (isset($_GET['sync'])) {
    $zip = new ZipArchive;

    if ($zip->open('uploads/update.zip') === TRUE) 
    {
        if ($zip->extractTo(FCPATH.'/')) {
       	 	$zip->close();
       	 	unlink('uploads/update.zip');
       	 	echo "
       	 		<script>
       	 			window.location.href='".base_url('update')."';
       	 		</script>
       	 	";
        }
    }
}
?>