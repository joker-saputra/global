<script src="<?= base_url(); ?>buildSystems/plugins/jquery/jquery.min.js"></script>
<script src="<?= base_url(); ?>buildSystems/plugins/jquery-ui/jquery-ui.min.js"></script>
<script>
  $.widget.bridge('uibutton', $.ui.button)
</script>
<script src="<?= base_url(); ?>buildSystems/plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
<script src="<?= base_url(); ?>buildSystems/plugins/chart.js/Chart.min.js"></script>
<script src="<?= base_url(); ?>buildSystems/plugins/sparklines/sparkline.js"></script>
<script src="<?= base_url(); ?>buildSystems/plugins/jqvmap/jquery.vmap.min.js"></script>
<script src="<?= base_url(); ?>buildSystems/plugins/jqvmap/maps/jquery.vmap.usa.js"></script>
<script src="<?= base_url(); ?>buildSystems/plugins/jquery-knob/jquery.knob.min.js"></script>
<script src="<?= base_url(); ?>buildSystems/plugins/moment/moment.min.js"></script>
<script src="<?= base_url(); ?>buildSystems/plugins/daterangepicker/daterangepicker.js"></script>
<script src="<?= base_url(); ?>buildSystems/plugins/tempusdominus-bootstrap-4/js/tempusdominus-bootstrap-4.min.js"></script>
<script src="<?= base_url(); ?>buildSystems/plugins/summernote/summernote-bs4.min.js"></script>
<script src="<?= base_url(); ?>buildSystems/plugins/overlayScrollbars/js/jquery.overlayScrollbars.min.js"></script>
<script src="<?= base_url(); ?>buildSystems/dist/js/adminlte.js"></script>
<script src="<?= base_url(); ?>buildSystems/dist/js/pages/dashboard.js"></script>
<script src="<?= base_url(); ?>buildSystems/dist/js/demo.js"></script>