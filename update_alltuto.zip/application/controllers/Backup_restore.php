<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Backup_restore extends CI_Controller {
	public function __construct(){
		parent::__construct();
		$this->load->model('sistem_aplikasi', 'sistem');
	}
	public function index(){
		$loaded['tittle'] = 'main/tittle';
		$loaded['metaLink'] = 'main/meta_link';
		$loaded['logo'] = 'main/logo';
		$loaded['menu'] = 'main/menu';
		$loaded['headerNavbar'] = 'main/header_navbar';
		$loaded['coreMenu'] = 'main/core_menu';
		$loaded['content'] = 'backup_restore';
		$loaded['footer'] = 'main/footer';
		$loaded['script'] = 'main/script';
		$this->load->view('main', $loaded);
	}
	function backup_database(){
	    $tables             = "*";
	    $this->sistem->export_database($tables=false);
	}
}
