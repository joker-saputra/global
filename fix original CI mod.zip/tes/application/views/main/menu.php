  <aside class="main-sidebar sidebar-dark-primary elevation-4">
    <?php $this->load->view($logo); ?>

    <div class="sidebar">

      <nav class="mt-2">
        <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu" data-accordion="false">
          <?php $this->load->view($coreMenu); ?>
        </ul>
      </nav>
    </div>
  </aside>