<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Sistem extends CI_Model {
	function versi(){
		return '0.1';
	}
}
