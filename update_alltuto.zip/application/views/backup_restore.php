<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<div class="row">
  <div class="col-12">
    <div class="card">
      <div class="card-header d-flex p-0">
        <h3 class="card-title p-3">
	      <i class="fas fa-download"></i>
	      Backup & Restore
	  	</h3>
        <ul class="nav nav-pills ml-auto p-2">
          <li class="nav-item"><a class="nav-link active" href="#tab_1" data-toggle="tab">Backup</a></li>
          <li class="nav-item"><a class="nav-link" href="#tab_2" data-toggle="tab">Restore</a></li>
        </ul>
      </div>
      <div class="card-body">
        <div class="tab-content">
          <div class="tab-pane text-center active" id="tab_1">
            <button class="btn btn-outline-success" onclick="window.open('<?= base_url('backup_restore/backup_database'); ?>');">Backup Database</button>
          </div>
          <div class="tab-pane" id="tab_2">
              <form method="post" enctype="multipart/form-data">
                <div class="form-group">
                  <label>File Backup</label>
                  <input type="file" name="filee" class="form-control" required>
                </div>
                <div class="btn btn-outline-warning" style="cursor: pointer;" data-toggle="modal" data-target="#modal-default">Proses</div>
                <div class="modal fade" id="modal-default" aria-hidden="true" style="display: none;">
                  <div class="modal-dialog">
                    <div class="modal-content">
                      <div class="modal-header">
                        <h4 class="modal-title">Default Modal</h4>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                          <span aria-hidden="true">×</span>
                        </button>
                      </div>
                      <div class="modal-body">
                        <p>Proses <b>RESTORE</b> akan menghapus data sebelumnya dan digantikan dengan data baru yang dimasukkan.!!</p>
                      </div>
                      <div class="modal-footer justify-content-between">
                        <button type="button" class="btn btn-default" data-dismiss="modal">Batal</button>
                        <button type="submit" class="btn btn-dangers" name="upload">Proses</button>
                      </div>
                    </div>
                  </div>
                </div>
              </form>
          </div>		                  
        </div>
      </div>
    </div>
  </div>
</div>
<?php
if (isset($_POST['upload'])) {
    // $mysqli = new mysqli('localhost','epiz_26213796','oixuXA4hjiAVJey','epiz_26213796_alltuto'); 
    $mysqli = new mysqli('sql302.epizy.com','epiz_26213796','oixuXA4hjsiAVJey','epiz_26213796_alltuto'); 
		$sql = "SHOW TABLES FROM `epiz_26213796_alltuto`";
		$result = mysqli_query($mysqli, $sql);
		if (!$result) {
		    echo "DB Error, could not list tables\n";
		    echo 'MySQL Error: ' . mysqli_error($mysqli);
		    exit;
		}
		while ($row = mysqli_fetch_row($result)) {
		    $table = $row[0];
		    mysqli_query($mysqli, "DROP TABLE IF EXISTS `epiz_26213796_alltuto`");
		}
		mysqli_free_result($result);
		$nama = $_FILES['filee']['name'];
		$tmp_name = file_get_contents($_FILES['filee']['tmp_name']);
		$proses = $mysqli->multi_query($tmp_name)or die(mysqli_error($mysqli));
		if ($proses) {
		  echo "
		    <script>
		      window.location.href='".base_url('backup_restore?alert='.base64_encode('Berhasil RESTORE databse dari file.').'&info='.base64_encode('success'))."';
		    </script>
		  ";
		}else{
		  echo "
		    <script>
		      window.location.href='".base_url('backup_restore?alert='.base64_encode('GAGAL RESTORE databse dari file.').'&info='.base64_encode('error'))."';
		    </script>
		  ";
		}
}
?>