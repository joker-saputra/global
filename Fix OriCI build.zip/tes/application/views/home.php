<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<div class="row">
	<div class="col-md-12">
		<div class="card card-default">
		  <div class="card-header">
		    <h3 class="card-title">
		      <i class="fas fa-exclamation-triangle"></i>
		      Alerts
		    </h3>
		  </div>
		  <!-- /.card-header -->
		  <div class="card-body">
		  	
		  </div>
		  <!-- /.card-body -->
		</div>
	<!-- /.card -->
	</div>
</div>