<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Main extends CI_Controller {
	public function __construct(){
		parent::__construct();
		$this->load->model('sistem_aplikasi', 'sistem');
	}
	public function index(){
		$loaded['tittle'] = 'main/tittle';
		$loaded['metaLink'] = 'main/meta_link';
		$loaded['logo'] = 'main/logo';
		$loaded['menu'] = 'main/menu';
		$loaded['headerNavbar'] = 'main/header_navbar';
		$loaded['coreMenu'] = 'main/core_menu';
		$loaded['content'] = 'home';
		$loaded['footer'] = 'main/footer';
		$loaded['script'] = 'main/script';
		$this->load->view('main', $loaded);
	}
}
